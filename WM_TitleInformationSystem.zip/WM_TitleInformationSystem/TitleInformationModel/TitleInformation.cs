﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TitleInformationModel
{
    public class TitleInformation
    {
        public int TitleID { get; set; }
        public string TitleName { get; set; }
        public int? ReleaseYear { get; set; }
        public string StoryDescription { get; set; }
        public string Language { get; set; }
        public string Types { get; set; }
        public string GenreName { get; set; }
        public string Actors { get; set; }
        public int NumberOfAward { get; set; }
        public int? AwardYear { get; set; }
        public string AwardCompany { get; set; }
    }
}