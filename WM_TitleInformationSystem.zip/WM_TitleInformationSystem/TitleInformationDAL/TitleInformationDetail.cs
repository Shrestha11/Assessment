﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TitleInformationModel;
using System.Data.SqlClient;
using System.Configuration;

namespace TitleInformationDAL
{
    //data access part
    public class TitleInformationDetail
    {
        string sp_GetTitleInformation = "GetTitleInformationByName";
        string conn = ConfigurationManager.ConnectionStrings["TitleConnect"].ToString();

        public IEnumerable<TitleInformation> GetTitleInformationDetail(string titleName)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                var command = new SqlCommand(sp_GetTitleInformation, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.Add("titleName", System.Data.SqlDbType.VarChar).Value = titleName;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                List<TitleInformation> titleList = new List<TitleInformation>();

                while (reader.Read())
                {
                    var title = new TitleInformation();
                    title.TitleID = int.Parse(reader["TitleId"].ToString());
                    title.TitleName = reader["TitleName"].ToString();
                    title.ReleaseYear = int.Parse(reader["ReleaseYear"].ToString());
                    title.StoryDescription = reader["StoryDescription"].ToString();
                    title.Language = reader["Language"].ToString();
                    title.Types = reader["Types"].ToString();
                    title.GenreName = reader["GenreName"].ToString();
                    title.Actors = reader["Actors"].ToString();
                    title.AwardYear = int.Parse(reader["AwardYear"].ToString());
                    title.NumberOfAward = int.Parse(reader["NumberOfAward"].ToString());
                    title.AwardCompany = reader["AwardCompany"].ToString();
                    titleList.Add(title);
                }
                return titleList;
            }
        }

        
    }
}
