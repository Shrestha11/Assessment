﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TitleInformationModel;
using TitleInformationDAL;


namespace WM_TitleInformationSystem.Models
{
    //all business logic about title information 
    public static class TitleInformationManagement
    {
        public static IEnumerable<TitleInformation> GetTitleInformationDetail(string titleName)
        {
            TitleInformationDetail data = new TitleInformationDetail();

            return (data.GetTitleInformationDetail(titleName));

        }
    }
}