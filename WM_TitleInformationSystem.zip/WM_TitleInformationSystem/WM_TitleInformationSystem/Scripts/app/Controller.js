﻿app.controller('titleController', function ($scope, $window, $location, $log, $anchorScroll, titleService) {
   
    $scope.isViewData = false;
    $scope.searchTitleName = ""; 
  
    $scope.searchTitle = function () {
        if ($scope.searchTitleName.length > 0) {
            GetByTitleName($scope.searchTitleName);
        }
    };
   
    //To Get All Records
    function GetByTitleName(titleName ) {
        var promiseGet = titleService.getByTitleName(titleName);
        promiseGet.then(function (pl) {
            $scope.titles = pl.data;
            if (pl.data.length > 0) {
                $scope.isViewData = true;
            }
        },
            function (errorPl) {
                $log.error('Some Error in Getting Records.', errorPl);
            });
    }

});