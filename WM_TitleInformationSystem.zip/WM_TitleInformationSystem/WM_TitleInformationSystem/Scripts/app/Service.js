﻿app.service('titleService', function ($http) {
       
    ////Get Title Information By Title Name
    this.getByTitleName = function (titleName) {
        return $http.get("/api/TitleInformation/" + titleName);
    }

    //Get All Title
    this.getAllTitle = function () {
        return $http.get("/api/TitleInformation");//
    }
      
  
});