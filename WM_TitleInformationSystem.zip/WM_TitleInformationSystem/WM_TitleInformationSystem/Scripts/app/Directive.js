﻿app.directive('titleForm',
    function () {

        return {
            restrict: 'E',
            templateUrl: '/Scripts/app/TitleInformation.html'
        }

    });