﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TitleInformationModel;
using WM_TitleInformationSystem.Models;

namespace WM_TitleInformationSystem.Controllers
{
    [RoutePrefix("api/TitleInformation")]
    public class TitleInformationController : ApiController
    {

        [HttpGet]
        [Route()]
        // GET api/TitleInformation
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet]       
        [Route("{titleName}")]
        // GET api/TitleInformation/titleName
        public IEnumerable<TitleInformation> Get(string titleName)
        {
            try
            {
               return( TitleInformationManagement.GetTitleInformationDetail(titleName));
            
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
            }

            return null;
        }

        // POST api/<controller>
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}