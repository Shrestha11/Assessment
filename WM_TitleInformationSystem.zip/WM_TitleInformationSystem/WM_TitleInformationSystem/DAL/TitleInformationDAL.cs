﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WM_TitleInformationSystem.Models;
using System.Data.SqlClient;
using System.Configuration;


namespace WM_TitleInformationSystem.DAL
{
    public class TitleInformationDAL
    {               
        string sp_GetTitleInformation  = "GetTitleInformationByName";
        string conn = ConfigurationManager.ConnectionStrings["TitleConnect"].ToString();
       
        public IEnumerable<TitleInformationModel> GetTitleInformationDetail(string titleName) 
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                var command = new SqlCommand(sp_GetTitleInformation, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.Add("titleName", System.Data.SqlDbType.VarChar).Value = titleName;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                List<TitleInformationModel> titleList = new List<TitleInformationModel>();

                while (reader.Read())
                {
                    var title = new TitleInformationModel();
                    title.TitleID = int.Parse(reader["TitleId"].ToString());
                    title.TitleName = reader["TitleName"].ToString();
                    title.ReleaseYear = int.Parse(reader["ReleaseYear"].ToString());
                    title.StoryDescription = reader["StoryDescription"].ToString();
                    title.Language = reader["Language"].ToString();
                    title.Types = reader["Types"].ToString();
                    title.GenreName= reader["GenreName"].ToString();
                    title.Actors = reader["Actors"].ToString();
                    title.AwardYear = int.Parse(reader["AwardYear"].ToString());
                    title.NumberOfAward = int.Parse(reader["NumberOfAward"].ToString());
                    title.AwardCompany = reader["AwardCompany"].ToString();
                    titleList.Add(title);
                }
                return titleList;
            }
           
        }

}
}